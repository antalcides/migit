This binary distribution of a GLUT 3.7 beta release has been built
for use with f90gl, the Fortran 90 interface for OpenGL and GLUT.

You should move the files to appropriate directories:

Move glut32.dll to the system directory
  e.g. c:\winnt\system32

Move glut32.lib to a library directory
  e.g. c:\Program Files\Microsoft Visual Studio\VC98\Lib

Move glut.h and glutf90.h to the include directory for OpenGL
  e.g. c:\Program Files\Microsoft Visual Studio\VC98\Include\GL

William Mitchell, May 7, 1999
