/*ESTE PROGRAMA SE OFRECE COMO EJEMPLO DE PROGRAMACION EN C
  POR TANTO PUEDE COPIARSE CON LIBERTAD.
  eddie_santillan@hotmail.com
  ESPOCH - Ing.Mec�nica - Riobamba - Ecuador - SurAm�rica */

#include <conio.h>
#include <dos.h>
#include <stdio.h>
#include <ctype.h>
#include <iostream.h>
#include <graphics.h>
#include <stdlib.h>

caratula();
borde();
mensaje();

main()
{
const int Mn=20;
int i,j,m,p,v,k,t,w,n,e,s,cont=1;
float a[15][16],b[15][16],tmp[1][16],c[15][16],f,z,h,suma,temp;
char Reini;
caratula();
do
{
clrscr();

borde();
gotoxy(3,3);
textbackground(BLUE);
textcolor(WHITE);
cprintf("\nINGRESE EL NUMERO DE ECUACIONES A RESOLVER : ");
cscanf("%d",&n);

//-----------------LEE MATRIZ A----------------
  for (i=1;i<=n;i++)
  {
  for (j=1;j<=n+1;j++)
  {
  gotoxy(4*j,2*i+4);
  cscanf("%f",&f);
  a[i][j]= f;
  b[i][j]=0;
  c[i][j]=0;
  }
  }
INI:
cont++;
//--------------transponer filas-----------------
	if (a[1][1]==0)
	{
	for(i=1;i<=n;i++)
	{
		if (a[i][1]!=0)
		{
			for (j=1;j<=n+1;j++)
			{
			tmp[1][j]=a[1][j];
			a[1][j]=a[i][j];
			a[i][j]=tmp[1][j];
			}
		}
	}
	}

//*********************************************
	for(i=1;i<=n;i++)
	{
	for(k=1;k<=n;k++)
	{
	if (i==k)
	{
	c[i][k]=1;
	}
	}
	}

for (i=1;i<=n;i++)
{
//----------------CALCULO PARA B-----------------
	for (t=i;t<=n;t++)
	{
		if (i==1)
		{
			b[t][i]=a[t][i];
		}
		else
		{
			suma = 0;
			for (k=1;k<i;k++)
			{
			suma= suma + b[t][k]*c[k][i];
			}
			b[t][i]=a[t][i]-suma;
		}
	}

//----------------CALCULO PARA C-----------------

for (v=i+1;v<=n;v++)
{
	if (i==1)
	{
		c[i][v]=a[i][v]/b[i][i];
	}
	else
	{
		suma = 0;
		for (k=1;k<=i;k++)
		{
			suma = suma + (b[i][k]*c[k][v]);
		}
		
			if (b[i][i]==0)
			{
				if(cont>=n)
				{
					printf("\n\n\n\n\t\t<<< NO EXISTE SOLUCION POR ESTE METODO >>>");
					getch();
					exit(1);
				}
				else
				{
					for(k=1;k<=n+1;k++)
					{
					tmp[1][k]=a[1][k];
					a[1][k]=a[cont][k];
					a[cont][k]=tmp[1][k];
					}
					goto INI;
				}
			}
			else
			{
				c[i][v]=(a[i][v]-suma)/b[i][i];
			}
		}
} //BUCLE PARA C

} //BUCLE GENERAL

//--------------------------

clrscr();
borde();
gotoxy(3,3);
textbackground(BLUE);
textcolor(WHITE);

cprintf("\nLAS MATRICES B Y C SON :");

for (i=1;i<=n;i++)
  {
  for (j=1;j<=n;j++)
  {
  gotoxy(8*(j-1)+4,2*i+4);
  cprintf("%5.2f",b[i][j]);
  //cout<<b[i][j];
  }
  }

//--------------------------

for (i=1;i<=n;i++)
  {
  for (j=1;j<=n;j++)
  {
  gotoxy(8*(j-1)+4,2*i+13);
  //cin>>f;
  cprintf("%5.2f",c[i][j]);
  //cout<<c[i][j];
  }
  }
getch();
getch();
//----------RESOLVER B---------

for (j=1;j<=n;j++)
{
b[j][n+1]=a[j][n+1];
}

for(k=1;k<=n;k++) {
    temp=b[k][k];
    for(j=1;j<=n+1;j++)
      b[k][j]=b[k][j]/temp;
    for(i=1;i<=n;i++) {
      if(i==k) continue;
      temp=b[i][k];
      for(j=1;j<=n+1;j++)
	b[i][j]-=temp*b[k][j];
    }
  }

//----------------RESOLVER C----------------------

for (j=1;j<=n;j++)
{
c[j][n+1]=b[j][n+1];
}

for(k=1;k<=n;k++) {
    temp=c[k][k];
    for(j=1;j<=n+1;j++)
      c[k][j]=c[k][j]/temp;
    for(i=1;i<=n;i++) {
      if(i==k) continue;
      temp=c[i][k];
      for(j=1;j<=n+1;j++)
	c[i][j]-=temp*c[k][j];
    }
  }
//--------------------------------------------------------------

clrscr();
borde();
gotoxy(3,3);
textbackground(BLUE);
textcolor(WHITE);
cprintf("\nLAS SOLUCIONES SON :");

  for (j=1;j<=n;j++)
  {
  gotoxy(8,2*j+4);
  cprintf("X%d = %f",j,c[j][n+1]);
  }
  getch();

  gotoxy(Mn,15);
  textcolor(BLACK);
  textbackground(WHITE);
  cprintf("���������������������������������������ͻ\n");
  gotoxy(Mn,16);
  cprintf("� DESEA REALIZAR OTRO CALCULO ? [S/N]   �\n");
  gotoxy(Mn,17);
  cprintf("���������������������������������������ͼ");

  textbackground(BLUE);
  textcolor(WHITE);

  gotoxy(Mn+38,16);
  cin>>Reini;
  //Reini=getch();
  }
  while(toupper(Reini)!='N');
  clrscr();
  printf("\n\n\n\n\n\n\n\n\n\n\n\t\t\t<<<  PROGRAMA FINALIZADO  >>>");

  }

borde()
{
 int a;
 textbackground(WHITE);
 clrscr();
 textcolor(BLUE);
 for(a=2;a<25;a++)
 {
  gotoxy(1,a);
  cprintf("��������������������������������������������������������������������������������");
 }
 textcolor(WHITE);
 textbackground(BLUE);
 gotoxy(80,24);
 cprintf("�");
 for(a=3;a<24;a++)
  {
   gotoxy(1,a);
   cprintf("�");
   gotoxy(80,a);
   cprintf("�");
  }
 for(a=2;a<80;a++)
  {
   gotoxy(a,2);
   cprintf("�");
   gotoxy(a,24);
   cprintf("�");
  }
 gotoxy(1,2);
 cprintf("�");
 gotoxy(80,2);
 cprintf("�");
 gotoxy(1,24);
 cprintf("�");
 textcolor(BLACK);
 textbackground(WHITE);
 gotoxy(8,1);
 cprintf("��������������������� METODO DE CHOLESKI ���������������������������");
 gotoxy(4,25);
 cprintf("������ FACULTAD DE MECANICA      ESCUELA DE INGENIERIA MECANICA ������");
return(0);
}


  caratula()
       {
	int gdriver=DETECT, gmode, errorcode;
	int i,jo,pe,j;
	float a,pm;
	initgraph(&gdriver, &gmode, " ");
	errorcode=graphresult();
	if (errorcode != grOk)
		{
		printf("Error gr�fico \n");
		printf("Presione cualquier tecla para terminar... ");
		getch();
		exit(1);
		}

	//delay(1000);
	setfillstyle(1,BLUE);
	bar3d(625,31,30,455,10,0);
	setfillstyle(1,BLUE);
	bar3d(61,159,588,61,0,0);
	settextstyle (2,0,12);
	/*HORIZ_DIR  =A PONER 0 PRA QUE SE HORIZONTAL*/
	settextstyle(3,HORIZ_DIR,4);
	setcolor(YELLOW);
	settextstyle(SANS_SERIF_FONT,0,3);  ///----AQUI 4,0,4
	outtextxy(120,190,"METODOS NUMERICOS");
	outtextxy(150,250,"  METODO DE CHOLESKI ");
	setcolor(CYAN);
	outtextxy(60,300,"Realizado por :");
	settextstyle(10,0,2);
	setcolor(WHITE);
	outtextxy(320,330,"EDDIE SANTILLAN");
	outtextxy(320,345,"FACULTAD DE MECANICA");
	outtextxy(320,360,"ESCUELA DE INGENIERIA MECANICA");
	outtextxy(320,375,"RIOBAMBA - ECUADOR");
	outtextxy(320,390,"eddie_santillan@hotmail.com");

	settextstyle(SANS_SERIF_FONT,0,10);
	setcolor(WHITE);
	outtextxy(50,425,"Escuela Superior Polit�cnica de Chimborazo");

	pe=250;
	setcolor(YELLOW);
	settextstyle(1,0,8);sound(pe); delay(99);
	outtextxy(120,60,"E ");sound(pe+10);delay(99);
	outtextxy(120,60,"  S ");sound(pe+20);delay(99);
	outtextxy(120,60,"    P ");sound(pe+30);delay(99);
	outtextxy(120,60,"      O ");sound(pe+40);delay(99);
	outtextxy(120,60,"        CH");sound(pe+50);delay(99);
	nosound();

	for(i=1;i<=15;i++)
	{
	setcolor(i*8); //**************************
	rectangle((20+i),(465-i),(637-i),(20+i));
	delay(40);
	}

	delay(300);

	for(i=1;i<=10;i++)
	{
	setcolor(i*8);  //*****************************
	rectangle((50+i),(170-i),(600-i),(50+i));delay(30);
	}
	 delay(600);
	 setcolor(13);
	 settextstyle(10,0,2);
	 setcolor(YELLOW);
	 outtextxy(440,440,"Presione una tecla ...");
	 getch();

	 for(i=15;i<=225;i++)
      {
	setcolor(i*8);                         //**********************
	rectangle((20+i),(465-i),(637-i),(20+i));
	delay(5);
      }

       setcolor(WHITE);
	settextstyle(3,0,6);
	outtextxy(70,210,"INGENIERIA MECANICA");

	delay(500);
	closegraph();
	return 0;
	}

/*mensaje()
{
window(15,15,54,20);
  textcolor(BLACK);
  textbackground(WHITE);
  cprintf("��������������������������������������ͻ");
  cprintf("� DESEA REALIZAR OTRO CALCULO ? [S/N]  � ");
  cprintf("��������������������������������������ͼ");
return (0);
}*/