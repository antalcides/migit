/*ESTE PROGRAMA SE OFRECE COMO EJEMPLO DE PROGRAMACION EN C
  POR TANTO PUEDE COPIARSE CON LIBERTAD.
  eddie_santillan@hotmail.com
  ESPOCH - Ing.Mec�nica - Riobamba - Ecuador - SurAm�rica */

#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<iostream.h>
#define M 50                        // M = MAX. NUMERO DE ECUACIONES
#define N M+1

main()
{
  float a[M][N], temp;
  int n, i, j, k;
  char str[20];

  clrscr();
  textbackground(BLUE);
  textcolor(WHITE);
  clrscr();
  cout<<"�������������������������� EJEMPLO DE PROGRAMACION EN C ������������������������";
  cout<<"\nMETODO DE GAUSS-JORDAN PARA LA SOLUCION DE SISTEMAS DE ECUACIONES";
  cout<<"\n\nIntroduzca el n�mero de ecuaciones : ";
  cin>>n;
  cout<<"\nIntroduzca la matriz aumentada de n,n+1\n";
  for(i=0;i<n;i++)
    for(j=0;j<=n;j++, a[i][j]=0);                 // ENCERA EL ARREGLO
  for(i=0;i<n;i++)
    for(j=0;j<=n;j++) {
      cout<<"valor de a["<<i+1<<","<<j+1<<"]?:";
      cin>>str;

    // Caracteres a float
      a[i][j]=atof(str);
    }
  printf("\n\n");
  for(i=0;i<n;i++)
    for(j=0;j<=n;j++) {
      printf("%3.3f\t",a[i][j]);
      if(j==n)printf("\n");
    }
  for(k=0;k<n;k++) {
    temp=a[k][k];
    for(j=0;j<=n;j++)
      a[k][j]=a[k][j]/temp;
    for(i=0;i<n;i++) {
      if(i==k) continue;
      temp=a[i][k];
      for(j=0;j<=n;j++)
	a[i][j]-=temp*a[k][j];
    }
  }

  //Matriz resultante

  printf("\n\n Soluciones :\n\n");
  for(i=0;i<n;i++)
    for(j=0;j<=n;j++) {
      printf("%3.3f\t",a[i][j]);
      if(j==n)printf("\n");
    }
  getch();
  return 0;
}
