======================================================================

			   TeXPower bundle
			  Directory: gallery

	    This readme file last changed on Mar 15, 2002

  Author: Stephan Lehmke <mailto:Stephan.Lehmke@cs.uni-dortmund.de>
	  Lehrstuhl Informatik I
	  Universit�t Dortmund
	  Dortmund, Germany

======================================================================


This directory contains some demos and examples of `real life'
presentations created with TeXPower by other people.


======================================================================

Contents:
=========

This directory contains the following files:

DeLegeLata.pdf

A presentation (in german) created by Heiner Richter
<heiner.richter@netcologne.de>.


MPostDemo.pdf

A demo for incremental MetaPost graphics created by Thorsten Ohl
<ohl@hep.tu-darmstadt.de>.


MethodOfLines.pdf

A presentation created by Wilfrid Pascher
<Wilfrid.Pascher@FernUni-Hagen.de>.


Pappus.pdf

A presentation created by Ross Moore <ross@ics.mq.edu.au> where
TeXPower and Xy-pic are combined.

Pappus.zip

Pappus.pdf zipped together with sources and required logos.


ShortVectors.pdf

A presentation created by Friedrich Eisenbrand <eisen@mpi-sb.mpg.de>.

